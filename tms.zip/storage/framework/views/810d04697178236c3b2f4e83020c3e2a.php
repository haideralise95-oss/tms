<?php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
?>
## Laravel Pint Code Formatter

- You must run ___SINGLE_BACKTICK___<?php echo e($assist->binCommand('pint')); ?> --dirty___SINGLE_BACKTICK___ before finalizing changes to ensure your code matches the project's expected style.
- Do not run ___SINGLE_BACKTICK___<?php echo e($assist->binCommand('pint')); ?> --test___SINGLE_BACKTICK___, simply run ___SINGLE_BACKTICK___<?php echo e($assist->binCommand('pint')); ?>___SINGLE_BACKTICK___ to fix any formatting issues.
<?php /**PATH D:\xampp8.2_latest\htdocs\tms\tms\storage\framework\views/95e7c3dc1b218271cdf2eb4c7d0dde59.blade.php ENDPATH**/ ?>